import random
import json
import logging

# Configure logging
logging.basicConfig(
    filename="chat_log.txt", 
    level=logging.INFO, 
    format="%(asctime)s - %(message)s"
)

def load_responses():
    """Load keywords and responses from a JSON configuration file."""
    try:
        with open("responses.json", "r") as file:
            return json.load(file)
    except FileNotFoundError:
        return {
            "keywords": {
                "coffee": "The campus coffee bar is open from 8 AM to 8 PM.",
                "library": "The library is open from 9 AM to 10 PM.",
                "courses": "We offer a wide range of courses in arts, science, and technology.",
                "sports": "The sports complex is open from 6 AM to 9 PM and offers various facilities."
            },
            "default_responses": [
                "I'm not sure about that. Can you ask something else?",
                "That's an interesting question!",
                "Let me think about that...",
                "I'm sorry, I don't have information on that.",
                "Could you clarify your question?"
            ]
        }

def random_agent_name():
    """Generate a random name for the agent."""
    agent_names = ["Alex", "Taylor", "Jordan", "Morgan", "Casey"]
    return random.choice(agent_names)

def main():
    responses = load_responses()
    agent_name = random_agent_name()

    print("Welcome to the University of Poppleton's chat system!")
    user_name = input("May I have your name, please? ")
    print(f"Hello, {user_name}! My name is {agent_name}, your virtual assistant.")
    logging.info(f"Session started with user: {user_name} and agent: {agent_name}")

    while True:
        user_input = input(f"{user_name}: ").strip().lower()
        logging.info(f"User: {user_input}")

        if user_input in {"bye", "exit", "quit"}:
            print(f"{agent_name}: It was nice chatting with you, {user_name}. Goodbye!")
            logging.info("Session ended by user.")
            break

        # Randomly disconnect the chat
        if random.random() < 0.05:  # 5% chance of disconnection
            print(f"{agent_name}: Oops! It seems we've been disconnected. Please try again later.")
            logging.info("Session disconnected randomly.")
            break

        # Check for keywords in user input
        response = None
        for keyword, reply in responses["keywords"].items():
            if keyword in user_input:
                response = reply
                break

        # If no keyword is found, use a random default response
        if not response:
            response = random.choice(responses["default_responses"])

        print(f"{agent_name}: {response}")
        logging.info(f"Agent: {response}")

if __name__ == "__main__":
    main()
