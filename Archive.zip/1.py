import sys
import os
from tabulate import tabulate

def read_file(file_path):
    """Read and parse the file content."""
    if not os.path.exists(file_path):
        print("Error: File does not exist.")
        sys.exit(1)

    with open(file_path, 'r') as file:
        lines = file.readlines()

    if not lines:
        print("Error: File is empty.")
        sys.exit(1)

    race_name = lines[0].strip()
    lap_data = [line.strip() for line in lines[1:]]
    return race_name, lap_data

def parse_lap_data(lap_data):
    """Parse lap data into a structured format."""
    driver_times = {}
    for entry in lap_data:
        driver_code = entry[:3]
        lap_time = float(entry[3:])

        if driver_code not in driver_times:
            driver_times[driver_code] = []

        driver_times[driver_code].append(lap_time)

    return driver_times

def compute_statistics(driver_times):
    """Compute required statistics."""
    fastest_overall = None
    fastest_driver = None

    stats = []
    all_lap_times = []

    for driver, times in driver_times.items():
        fastest_time = min(times)
        average_time = sum(times) / len(times)

        if fastest_overall is None or fastest_time < fastest_overall:
            fastest_overall = fastest_time
            fastest_driver = driver

        all_lap_times.extend(times)

        stats.append({
            "driver": driver,
            "fastest_time": fastest_time,
            "average_time": average_time,
            "total_laps": len(times)
        })

    overall_average = sum(all_lap_times) / len(all_lap_times) if all_lap_times else None

    return stats, fastest_driver, fastest_overall, overall_average

def display_results(race_name, stats, fastest_driver, fastest_overall, overall_average):
    """Display the computed results."""
    print(f"Race: {race_name}\n")
    print(f"Fastest Driver Overall: {fastest_driver} ({fastest_overall:.3f}s)\n")

    if overall_average is not None:
        print(f"Overall Average Lap Time: {overall_average:.3f}s\n")

    stats_table = [
        [stat["driver"], stat["fastest_time"], stat["average_time"], stat["total_laps"]]
        for stat in stats
    ]

    print(tabulate(stats_table, headers=["Driver", "Fastest Time", "Average Time", "Total Laps"], floatfmt=".3f"))

    print("\nFastest Times in Descending Order:")
    sorted_stats = sorted(stats, key=lambda x: x["fastest_time"])
    sorted_table = [
        [stat["driver"], stat["fastest_time"]] for stat in sorted_stats
    ]
    print(tabulate(sorted_table, headers=["Driver", "Fastest Time"], floatfmt=".3f"))

def main():
    if len(sys.argv) < 2:
        print("Usage: python f1_timing_analysis.py <file_path>")
        sys.exit(1)

    file_path = sys.argv[1]
    race_name, lap_data = read_file(file_path)
    driver_times = parse_lap_data(lap_data)
    stats, fastest_driver, fastest_overall, overall_average = compute_statistics(driver_times)
    display_results(race_name, stats, fastest_driver, fastest_overall, overall_average)

if __name__ == "__main__":
    main()

    